# Projeto modelo para os projetos de PI de 1º semestre

Público alvo: Alunos do 1º semestre em 2020/1.
